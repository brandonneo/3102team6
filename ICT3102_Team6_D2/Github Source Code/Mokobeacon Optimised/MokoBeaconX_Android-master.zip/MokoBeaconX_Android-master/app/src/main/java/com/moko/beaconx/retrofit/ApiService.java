package com.moko.beaconx.retrofit;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {

    @GET("newbeacondetect")
    public Call<ResponseBody> getnewbeacondetect(
            @Query("staff_id") String staff_id,
            @Query("beacon_address") String beacon_address,
            @Query("rssi") int rssi);
}