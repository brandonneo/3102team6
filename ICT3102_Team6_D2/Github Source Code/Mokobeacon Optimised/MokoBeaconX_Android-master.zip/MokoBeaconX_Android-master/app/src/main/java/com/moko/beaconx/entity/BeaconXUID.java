package com.moko.beaconx.entity;

import java.io.Serializable;


public class BeaconXUID implements Serializable {
    public String rangingData;
    public String namespace;
    public String instanceId;
}
