package com.moko.support.event;

public class ConnectStatusEvent {
    private String action;

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

}
